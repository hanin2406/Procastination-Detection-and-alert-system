chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url) {
    const blockedSites = ['youtube.com', 'instagram.com'];
    for (const site of blockedSites) {
      if (tab.url.includes(site)) {
        chrome.tabs.update(tabId, {
          url: chrome.runtime.getURL('blocked.html')
        });
        break;
      }
    }
  }
});
